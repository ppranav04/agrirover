/*
 * Arduino Servo Position Test Program - SMOOTH VERSION
 * 
 * Moves servos with smooth interpolation between positions.
 * 
 * Initial Position:
 * - Pin 3 (Servo 1): 90°
 * - Pin 6 (Servo 2): 30°
 * - Pin 9 (Servo 3): 180°
 * - Pin 10 (Servo 4): 0°
 * 
 * After 5 second delay, smoothly moves to:
 * - Pin 3 (Servo 1): 90° (no change)
 * - Pin 6 (Servo 2): 120°
 * - Pin 9 (Servo 3): 150°
 * - Pin 10 (Servo 4): 0° (no change)
 * 
 * Features:
 * - Smooth interpolation (2° per step)
 * - Serial debugging output
 * - Configurable delays and step size
 * - Movement duration tracking
 */

#include <Servo.h>
#include <Arduino.h>

// ============================================================
// CONFIGURATION
// ============================================================

#define SLEEP_DURATION_MS 8000      // 5 second delay
#define MOVEMENT_STEP_SIZE 2        // Degrees per interpolation step
#define INTERPOLATION_DELAY_MS 20   // Milliseconds between steps

// Servo pins
#define PIN_SERVO1 3
#define PIN_SERVO2 6
#define PIN_SERVO3 9
#define PIN_SERVO4 10

// ============================================================
// INITIAL POSITIONS (degrees)
// ============================================================

const uint8_t INITIAL_POS_1 = 90;   // Pin 3
const uint8_t INITIAL_POS_2 = 30;   // Pin 6
const uint8_t INITIAL_POS_3 = 180;  // Pin 9
const uint8_t INITIAL_POS_4 = 0;    // Pin 10

// ============================================================
// FINAL POSITIONS (degrees) - After sleep
// ============================================================

const uint8_t FINAL_POS_1 = 90;     // Pin 3 (no change, stays 90)
const uint8_t FINAL_POS_2 = 120;    // Pin 6 (changes from 30 to 120)
const uint8_t FINAL_POS_3 = 150;    // Pin 9 (changes from 180 to 150)
const uint8_t FINAL_POS_4 = 0;      // Pin 10 (no change, stays 0)

// ============================================================
// SERVO OBJECTS & STATE
// ============================================================

Servo servo1, servo2, servo3, servo4;
uint8_t current_pos_1, current_pos_2, current_pos_3, current_pos_4;
bool moved_to_final = false;
unsigned long start_time = 0;
unsigned long movement_start_time = 0;

// ============================================================
// SETUP
// ============================================================

void setup() {
  // Initialize serial for debugging
  Serial.begin(9600);
  delay(1000);
  
  // Print header
  Serial.println("\n\n╔════════════════════════════════════════╗");
  Serial.println("║  Servo Position Test Program - SMOOTH  ║");
  Serial.println("╚════════════════════════════════════════╝\n");
  
  // Attach servos to pins
  servo1.attach(PIN_SERVO1);
  servo2.attach(PIN_SERVO2);
  servo3.attach(PIN_SERVO3);
  servo4.attach(PIN_SERVO4);
  
  // Set initial positions
  servo1.write(INITIAL_POS_1);
  servo2.write(INITIAL_POS_2);
  servo3.write(INITIAL_POS_3);
  servo4.write(INITIAL_POS_4);
  
  // Store current positions
  current_pos_1 = INITIAL_POS_1;
  current_pos_2 = INITIAL_POS_2;
  current_pos_3 = INITIAL_POS_3;
  current_pos_4 = INITIAL_POS_4;
  
  // Start timer
  start_time = millis();
  
  // Print initial positions
  Serial.println("┌─ INITIAL POSITIONS ─────────────────────┐");
  Serial.print("│ Pin 3  (Servo 1): ");
  Serial.print(INITIAL_POS_1);
  Serial.println("°                     │");
  Serial.print("│ Pin 6  (Servo 2): ");
  Serial.print(INITIAL_POS_2);
  Serial.println("°                     │");
  Serial.print("│ Pin 9  (Servo 3): ");
  Serial.print(INITIAL_POS_3);
  Serial.println("°                    │");
  Serial.print("│ Pin 10 (Servo 4): ");
  Serial.print(INITIAL_POS_4);
  Serial.println("°                     │");
  Serial.println("└─────────────────────────────────────────┘");
  
  Serial.print("\n⏱  Waiting ");
  Serial.print(SLEEP_DURATION_MS / 1000);
  Serial.println(" seconds before movement...\n");
}

// ============================================================
// MAIN LOOP
// ============================================================

void loop() {
  unsigned long current_time = millis();
  unsigned long elapsed = current_time - start_time;
  
  // Check if sleep duration has passed
  if (!moved_to_final && elapsed >= SLEEP_DURATION_MS) {
    Serial.println("⏱  Sleep timer expired! Starting smooth movement...\n");
    movement_start_time = current_time;
    moved_to_final = true;
  }
  
  // Execute smooth movement after timer
  if (moved_to_final) {
    move_servos_smoothly();
  }
  
  delay(10);  // Small delay in main loop
}

// ============================================================
// SMOOTH MOVEMENT FUNCTION
// ============================================================

void move_servos_smoothly() {
  // Calculate if all servos reached their targets
  bool all_reached = true;
  
  // Servo 1: Move from INITIAL_POS_1 to FINAL_POS_1
  if (current_pos_1 != FINAL_POS_1) {
    all_reached = false;
    
    if (current_pos_1 < FINAL_POS_1) {
      current_pos_1 = min(current_pos_1 + MOVEMENT_STEP_SIZE, FINAL_POS_1);
    } else {
      current_pos_1 = max((int16_t)current_pos_1 - MOVEMENT_STEP_SIZE, (int16_t)FINAL_POS_1);
    }
    
    servo1.write(current_pos_1);
  }
  
  // Servo 2: Move from INITIAL_POS_2 to FINAL_POS_2
  if (current_pos_2 != FINAL_POS_2) {
    all_reached = false;
    
    if (current_pos_2 < FINAL_POS_2) {
      current_pos_2 = min(current_pos_2 + MOVEMENT_STEP_SIZE, FINAL_POS_2);
    } else {
      current_pos_2 = max((int16_t)current_pos_2 - MOVEMENT_STEP_SIZE, (int16_t)FINAL_POS_2);
    }
    
    servo2.write(current_pos_2);
  }
  
  // Servo 3: Move from INITIAL_POS_3 to FINAL_POS_3
  if (current_pos_3 != FINAL_POS_3) {
    all_reached = false;
    
    if (current_pos_3 < FINAL_POS_3) {
      current_pos_3 = min(current_pos_3 + MOVEMENT_STEP_SIZE, FINAL_POS_3);
    } else {
      current_pos_3 = max((int16_t)current_pos_3 - MOVEMENT_STEP_SIZE, (int16_t)FINAL_POS_3);
    }
    
    servo3.write(current_pos_3);
  }
  
  // Servo 4: Move from INITIAL_POS_4 to FINAL_POS_4
  if (current_pos_4 != FINAL_POS_4) {
    all_reached = false;
    
    if (current_pos_4 < FINAL_POS_4) {
      current_pos_4 = min(current_pos_4 + MOVEMENT_STEP_SIZE, FINAL_POS_4);
    } else {
      current_pos_4 = max((int16_t)current_pos_4 - MOVEMENT_STEP_SIZE, (int16_t)FINAL_POS_4);
    }
    
    servo4.write(current_pos_4);
  }
  
  // Print current positions every 10 steps
  static uint8_t step_counter = 0;
  step_counter++;
  
  if (step_counter >= 10) {
    step_counter = 0;
    unsigned long movement_elapsed = millis() - movement_start_time;
    
    Serial.print("⏳ Moving... ");
    Serial.print(movement_elapsed);
    Serial.print("ms | Positions: [");
    Serial.print(current_pos_1);
    Serial.print("°, ");
    Serial.print(current_pos_2);
    Serial.print("°, ");
    Serial.print(current_pos_3);
    Serial.print("°, ");
    Serial.print(current_pos_4);
    Serial.println("°]");
  }
  
  // Print final positions when all servos reached target
  static bool movement_complete = false;
  if (all_reached && !movement_complete) {
    unsigned long total_movement_time = millis() - movement_start_time;
    movement_complete = true;
    
    Serial.println("\n┌─ FINAL POSITIONS REACHED ───────────────┐");
    Serial.print("│ Pin 3  (Servo 1): ");
    Serial.print(current_pos_1);
    Serial.println("°                     │");
    Serial.print("│ Pin 6  (Servo 2): ");
    Serial.print(current_pos_2);
    Serial.println("°                    │");
    Serial.print("│ Pin 9  (Servo 3): ");
    Serial.print(current_pos_3);
    Serial.println("°                    │");
    Serial.print("│ Pin 10 (Servo 4): ");
    Serial.print(current_pos_4);
    Serial.println("°                     │");
    Serial.println("└─────────────────────────────────────────┘");
    
    Serial.print("\n✓ Total movement time: ");
    Serial.print(total_movement_time);
    Serial.println("ms");
    Serial.println("✓ All servos at target positions!\n");
  }
  
  // Apply interpolation delay
  delay(INTERPOLATION_DELAY_MS);
}
