#!/usr/bin/env python3
"""
Tomato Detection Camera Node - Testing Suite
Tests 5 Key Metrics:
1. Classification Accuracy (Ripe vs. Unripe)
2. Depth Estimation Accuracy (RMSE)
3. XY Coordinate Accuracy (2D Detection)
4. Confidence Score Distribution & Optimal Threshold
5. Temporal Consistency (Frame-to-Frame Stability)
"""

import os
import json
import numpy as np
import cv2
from pathlib import Path
from typing import Dict, List, Tuple
from dataclasses import dataclass, field, asdict
from datetime import datetime
import subprocess
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Bool
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from collections import deque
import threading
import time
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support, accuracy_score


@dataclass
class ClassificationResult:
    """Store classification test results"""
    image_name: str
    ground_truth_label: int  # 0=unripe, 1=ripe
    predicted_label: int
    confidence: float
    is_correct: bool = field(default=False)
    
    def __post_init__(self):
        self.is_correct = self.ground_truth_label == self.predicted_label


@dataclass
class DepthResult:
    """Store depth estimation test results"""
    ground_truth_depth: float  # meters
    estimated_depth: float  # meters
    error: float = field(default=0.0)
    error_percent: float = field(default=0.0)
    
    def __post_init__(self):
        self.error = abs(self.estimated_depth - self.ground_truth_depth)
        self.error_percent = (self.error / self.ground_truth_depth * 100) if self.ground_truth_depth > 0 else 0


@dataclass
class XYAccuracyResult:
    """Store 2D coordinate accuracy results"""
    image_name: str
    true_bbox: Tuple[float, float, float, float]  # x1, y1, x2, y2
    pred_bbox: Tuple[float, float, float, float]
    pixel_error: float = field(default=0.0)
    iou: float = field(default=0.0)
    
    def __post_init__(self):
        # Calculate center-based pixel error
        true_center = ((self.true_bbox[0] + self.true_bbox[2]) / 2,
                       (self.true_bbox[1] + self.true_bbox[3]) / 2)
        pred_center = ((self.pred_bbox[0] + self.pred_bbox[2]) / 2,
                       (self.pred_bbox[1] + self.pred_bbox[3]) / 2)
        
        self.pixel_error = np.sqrt((true_center[0] - pred_center[0])**2 + 
                                    (true_center[1] - pred_center[1])**2)
        
        # Calculate IoU
        self.iou = self._calculate_iou(self.true_bbox, self.pred_bbox)
    
    @staticmethod
    def _calculate_iou(box1: Tuple, box2: Tuple) -> float:
        """Calculate Intersection over Union"""
        x1_1, y1_1, x2_1, y2_1 = box1
        x1_2, y1_2, x2_2, y2_2 = box2
        
        # Intersection
        inter_x1 = max(x1_1, x1_2)
        inter_y1 = max(y1_1, y1_2)
        inter_x2 = min(x2_1, x2_2)
        inter_y2 = min(y2_1, y2_2)
        
        inter_area = max(0, inter_x2 - inter_x1) * max(0, inter_y2 - inter_y1)
        
        # Union
        box1_area = (x2_1 - x1_1) * (y2_1 - y1_1)
        box2_area = (x2_2 - x1_2) * (y2_2 - y1_2)
        union_area = box1_area + box2_area - inter_area
        
        return inter_area / union_area if union_area > 0 else 0


@dataclass
class ConfidenceThresholdResult:
    """Store threshold analysis results"""
    threshold: float
    precision: float
    recall: float
    f1_score: float
    true_positives: int
    false_positives: int
    false_negatives: int


@dataclass
class TemporalConsistencyResult:
    """Store temporal stability results"""
    frame_id: int
    x_pos: float
    y_pos: float
    z_pos: float


class TomatoDetectionTester:
    """Main testing suite for tomato detection camera node"""
    
    def __init__(self, config_file: str = "test_config.json"):
        self.config = self.load_config(config_file)
        self.bridge = CvBridge()
        
        # Storage for test results
        self.classification_results: List[ClassificationResult] = []
        self.depth_results: Dict[float, List[DepthResult]] = {}
        self.xy_accuracy_results: List[XYAccuracyResult] = []
        self.confidence_results: List[dict] = []
        self.temporal_results: List[TemporalConsistencyResult] = []
        
        # ROS subscriber for goal poses
        self.pose_buffer = deque(maxlen=300)  # Store last 300 poses
        self.rclpy_initialized = False
        
        print("═" * 70)
        print("  TOMATO DETECTION TESTING SUITE")
        print("═" * 70)
    
    def load_config(self, config_file: str) -> dict:
        """Load test configuration"""
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                return json.load(f)
        
        # Default configuration
        return {
            "test_images_dir": "test_images/",
            "depth_test_distances": [0.15, 0.20, 0.25, 0.30, 0.40, 0.50],
            "frames_per_distance": 10,
            "confidence_thresholds": [0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9],
            "temporal_test_duration": 200,  # frames
            "output_dir": "test_results/",
            "model_path": "/home/pranav/agrirover_ws/src/yolov8n_tomato.pt"
        }
    
    # ====================================================================
    # METRIC 1: CLASSIFICATION ACCURACY
    # ====================================================================
    
    def test_classification_accuracy(self) -> Dict:
        """
        Test 1: Classification Accuracy (Ripe vs. Unripe)
        
        Process:
        1. Load test images from labeled folders (ripe/ and unripe/)
        2. Run YOLO inference on each image
        3. Compare predictions with ground truth labels
        4. Calculate metrics: Precision, Recall, F1-Score per class
        """
        print("\n" + "=" * 70)
        print("TEST 1: CLASSIFICATION ACCURACY")
        print("=" * 70)
        
        test_dir = Path(self.config["test_images_dir"])
        if not test_dir.exists():
            print("✗ Test images directory not found!")
            print(f"  Expected: {test_dir}")
            print("  Create folder structure:")
            print(f"    {test_dir}/ripe/      (images of ripe tomatoes)")
            print(f"    {test_dir}/unripe/    (images of unripe tomatoes)")
            return {}
        
        # Load YOLO model
        try:
            from ultralytics import YOLO
            model = YOLO(self.config["model_path"])
            print(f"✓ Model loaded: {self.config['model_path']}")
        except Exception as e:
            print(f"✗ Failed to load model: {e}")
            return {}
        
        # Test ripe tomatoes (label = 1)
        ripe_dir = test_dir / "ripe"
        if ripe_dir.exists():
            for img_file in ripe_dir.glob("*.jpg"):
                img = cv2.imread(str(img_file))
                results = model(img, conf=0.5, verbose=False)
                
                for result in results:
                    for box in result.boxes:
                        confidence = float(box.conf[0].cpu().numpy())
                        pred_label = 1  # Assuming ripe detection
                        
                        result_entry = ClassificationResult(
                            image_name=img_file.name,
                            ground_truth_label=1,
                            predicted_label=pred_label,
                            confidence=confidence
                        )
                        self.classification_results.append(result_entry)
        
        # Test unripe tomatoes (label = 0)
        unripe_dir = test_dir / "unripe"
        if unripe_dir.exists():
            for img_file in unripe_dir.glob("*.jpg"):
                img = cv2.imread(str(img_file))
                results = model(img, conf=0.5, verbose=False)
                
                for result in results:
                    for box in result.boxes:
                        confidence = float(box.conf[0].cpu().numpy())
                        pred_label = 0  # Assuming unripe detection
                        
                        result_entry = ClassificationResult(
                            image_name=img_file.name,
                            ground_truth_label=0,
                            predicted_label=pred_label,
                            confidence=confidence
                        )
                        self.classification_results.append(result_entry)
        
        # Calculate metrics
        if len(self.classification_results) == 0:
            print("✗ No detections found!")
            return {}
        
        y_true = [r.ground_truth_label for r in self.classification_results]
        y_pred = [r.predicted_label for r in self.classification_results]
        
        # Overall accuracy
        overall_accuracy = accuracy_score(y_true, y_pred)
        
        # Per-class metrics
        precision, recall, f1, support = precision_recall_fscore_support(y_true, y_pred, average=None)
        
        # Confusion matrix
        cm = confusion_matrix(y_true, y_pred)
        
        # Results dictionary
        results = {
            "overall_accuracy": float(overall_accuracy),
            "ripe_precision": float(precision[1]),
            "ripe_recall": float(recall[1]),
            "ripe_f1": float(f1[1]),
            "unripe_precision": float(precision[0]),
            "unripe_recall": float(recall[0]),
            "unripe_f1": float(f1[0]),
            "confusion_matrix": cm.tolist(),
            "total_samples": len(self.classification_results)
        }
        
        # Print results
        print(f"\n✓ Classification Test Complete")
        print(f"  Total Samples: {len(self.classification_results)}")
        print(f"\n  RIPE TOMATO:")
        print(f"    Precision: {results['ripe_precision']:.4f}")
        print(f"    Recall:    {results['ripe_recall']:.4f}")
        print(f"    F1-Score:  {results['ripe_f1']:.4f}")
        print(f"\n  UNRIPE TOMATO:")
        print(f"    Precision: {results['unripe_precision']:.4f}")
        print(f"    Recall:    {results['unripe_recall']:.4f}")
        print(f"    F1-Score:  {results['unripe_f1']:.4f}")
        print(f"\n  OVERALL ACCURACY: {results['overall_accuracy']:.4f} ({results['overall_accuracy']*100:.2f}%)")
        print(f"\n  Confusion Matrix:")
        print(f"    TN={cm[0,0]}  FP={cm[0,1]}")
        print(f"    FN={cm[1,0]}  TP={cm[1,1]}")
        
        return results
    
    # ====================================================================
    # METRIC 2: DEPTH ESTIMATION ACCURACY (RMSE)
    # ====================================================================
    
    def test_depth_estimation(self, manual_measurements: Dict[float, List[float]]) -> Dict:
        """
        Test 2: Depth Estimation Accuracy
        
        Input: manual_measurements - Dictionary with depth -> [list of estimated values]
        Example:
        {
            0.20: [0.198, 0.202, 0.195, 0.201, ...],  # 10 measurements at 0.20m
            0.30: [0.298, 0.305, 0.301, 0.299, ...],  # 10 measurements at 0.30m
        }
        
        Process:
        1. For each ground truth distance
        2. Calculate RMSE against estimated values
        3. Calculate MAE and error percentage
        4. Generate statistics
        """
        print("\n" + "=" * 70)
        print("TEST 2: DEPTH ESTIMATION ACCURACY (RMSE)")
        print("=" * 70)
        
        if not manual_measurements:
            print("✗ No depth measurements provided!")
            print("\nHow to collect measurements:")
            print("1. Place tomato at known distance (use measuring tape)")
            print("2. Run camera_node and capture goal_pose z-coordinates")
            print("3. Collect 10+ measurements per distance")
            print("4. Format as: {distance_m: [z_estimate_1, z_estimate_2, ...]}")
            return {}
        
        results_by_distance = {}
        all_results = []
        
        for ground_truth_distance, estimated_depths in manual_measurements.items():
            depth_results = []
            
            for z_est in estimated_depths:
                result = DepthResult(
                    ground_truth_depth=ground_truth_distance,
                    estimated_depth=z_est
                )
                depth_results.append(result)
                all_results.append(result)
            
            self.depth_results[ground_truth_distance] = depth_results
            
            # Calculate statistics for this distance
            errors = [r.error for r in depth_results]
            rmse = np.sqrt(np.mean(np.array(errors)**2))
            mae = np.mean(errors)
            error_percent = (rmse / ground_truth_distance) * 100
            
            results_by_distance[ground_truth_distance] = {
                "count": len(depth_results),
                "rmse_m": float(rmse),
                "mae_m": float(mae),
                "error_percent": float(error_percent),
                "min_error_m": float(min(errors)),
                "max_error_m": float(max(errors)),
                "std_dev_m": float(np.std(errors))
            }
        
        # Overall statistics
        all_errors = [r.error for r in all_results]
        overall_rmse = np.sqrt(np.mean(np.array(all_errors)**2))
        overall_mae = np.mean(all_errors)
        overall_avg_distance = np.mean([r.ground_truth_depth for r in all_results])
        overall_error_percent = (overall_rmse / overall_avg_distance) * 100
        
        # Print results
        print(f"\n✓ Depth Estimation Test Complete")
        print(f"  Total Measurements: {len(all_results)}")
        print(f"  Distance Range: {min(manual_measurements.keys()):.2f}m - {max(manual_measurements.keys()):.2f}m")
        print(f"\n  OVERALL STATISTICS:")
        print(f"    RMSE:     {overall_rmse:.4f}m ({overall_error_percent:.2f}%)")
        print(f"    MAE:      {overall_mae:.4f}m")
        print(f"    Std Dev:  {np.std(all_errors):.4f}m")
        print(f"    Min Error: {min(all_errors):.4f}m")
        print(f"    Max Error: {max(all_errors):.4f}m")
        
        print(f"\n  PER-DISTANCE BREAKDOWN:")
        for distance, stats in sorted(results_by_distance.items()):
            print(f"    {distance:.2f}m: RMSE={stats['rmse_m']:.4f}m ({stats['error_percent']:.2f}%), "
                  f"n={stats['count']}, σ={stats['std_dev_m']:.4f}m")
        
        return {
            "overall_rmse_m": float(overall_rmse),
            "overall_mae_m": float(overall_mae),
            "overall_error_percent": float(overall_error_percent),
            "per_distance": results_by_distance,
            "total_measurements": len(all_results)
        }
    
    # ====================================================================
    # METRIC 3: XY COORDINATE ACCURACY
    # ====================================================================
    
    def test_xy_accuracy(self, gt_bboxes: Dict[str, Tuple]) -> Dict:
        """
        Test 3: XY Coordinate Accuracy (2D Detection)
        
        Input: gt_bboxes - Dictionary with image_name -> (x1, y1, x2, y2)
        Example:
        {
            "tomato_001.jpg": (100, 150, 250, 280),
            "tomato_002.jpg": (80, 120, 220, 310),
        }
        
        Process:
        1. Run detection on images with ground truth bboxes
        2. Calculate pixel-space error (center distance)
        3. Calculate IoU (bounding box overlap)
        4. Generate statistics
        """
        print("\n" + "=" * 70)
        print("TEST 3: XY COORDINATE ACCURACY (2D Detection)")
        print("=" * 70)
        
        if not gt_bboxes:
            print("✗ No ground truth bounding boxes provided!")
            print("\nHow to create ground truth:")
            print("1. Manually annotate test images with bounding boxes")
            print("2. Format: image_name -> (x1, y1, x2, y2)")
            print("3. Example: {'tomato_001.jpg': (100, 150, 250, 280), ...}")
            return {}
        
        try:
            from ultralytics import YOLO
            model = YOLO(self.config["model_path"])
        except Exception as e:
            print(f"✗ Failed to load model: {e}")
            return {}
        
        # Process each image
        for img_name, true_bbox in gt_bboxes.items():
            img_path = Path(self.config["test_images_dir"]) / img_name
            
            if not img_path.exists():
                print(f"⚠ Image not found: {img_path}")
                continue
            
            img = cv2.imread(str(img_path))
            results = model(img, conf=0.5, verbose=False)
            
            for result in results:
                for box in result.boxes:
                    pred_bbox = tuple(box.xyxy[0].cpu().numpy())
                    
                    acc_result = XYAccuracyResult(
                        image_name=img_name,
                        true_bbox=true_bbox,
                        pred_bbox=pred_bbox
                    )
                    self.xy_accuracy_results.append(acc_result)
        
        if len(self.xy_accuracy_results) == 0:
            print("✗ No detections found!")
            return {}
        
        # Calculate statistics
        pixel_errors = [r.pixel_error for r in self.xy_accuracy_results]
        ious = [r.iou for r in self.xy_accuracy_results]
        
        results = {
            "mean_pixel_error_px": float(np.mean(pixel_errors)),
            "std_pixel_error_px": float(np.std(pixel_errors)),
            "min_pixel_error_px": float(np.min(pixel_errors)),
            "max_pixel_error_px": float(np.max(pixel_errors)),
            "mean_iou": float(np.mean(ious)),
            "std_iou": float(np.std(ious)),
            "min_iou": float(np.min(ious)),
            "max_iou": float(np.max(ious)),
            "total_detections": len(self.xy_accuracy_results),
            "good_iou_count": sum(1 for iou in ious if iou >= 0.75)
        }
        
        # Print results
        print(f"\n✓ XY Accuracy Test Complete")
        print(f"  Total Detections: {len(self.xy_accuracy_results)}")
        print(f"\n  PIXEL ERROR STATISTICS:")
        print(f"    Mean:   {results['mean_pixel_error_px']:.2f} pixels")
        print(f"    Std:    {results['std_pixel_error_px']:.2f} pixels")
        print(f"    Range:  {results['min_pixel_error_px']:.2f} - {results['max_pixel_error_px']:.2f} pixels")
        print(f"\n  IoU (BOUNDING BOX) STATISTICS:")
        print(f"    Mean:   {results['mean_iou']:.4f}")
        print(f"    Std:    {results['std_iou']:.4f}")
        print(f"    Range:  {results['min_iou']:.4f} - {results['max_iou']:.4f}")
        print(f"    Good (≥0.75): {results['good_iou_count']}/{len(self.xy_accuracy_results)}")
        
        return results
    
    # ====================================================================
    # METRIC 4: CONFIDENCE THRESHOLD OPTIMIZATION
    # ====================================================================
    
    def test_confidence_thresholds(self, detections_data: List[Dict]) -> Dict:
        """
        Test 4: Confidence Score Distribution & Optimal Threshold
        
        Input: detections_data - List of detection dictionaries
        Example:
        [
            {"confidence": 0.95, "is_correct": True},
            {"confidence": 0.42, "is_correct": False},
            ...
        ]
        
        Process:
        1. For each threshold value [0.3 - 0.9]
        2. Filter detections above threshold
        3. Calculate Precision, Recall, F1-Score
        4. Find optimal threshold (max F1-Score)
        """
        print("\n" + "=" * 70)
        print("TEST 4: CONFIDENCE THRESHOLD OPTIMIZATION")
        print("=" * 70)
        
        if not detections_data:
            print("✗ No detection data provided!")
            print("\nHow to collect detection data:")
            print("1. Run inference on test images")
            print("2. For each detection: record (confidence, is_correct)")
            print("3. Format: [{'confidence': 0.95, 'is_correct': True}, ...]")
            return {}
        
        thresholds = self.config["confidence_thresholds"]
        threshold_results = []
        
        for threshold in thresholds:
            # Filter detections by threshold
            filtered_detections = [d for d in detections_data if d["confidence"] >= threshold]
            
            if len(filtered_detections) == 0:
                continue
            
            # Calculate metrics
            tp = sum(1 for d in filtered_detections if d["is_correct"])
            fp = sum(1 for d in filtered_detections if not d["is_correct"])
            fn = sum(1 for d in detections_data if not d["is_correct"] and d["confidence"] < threshold)
            
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0
            f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
            
            result = ConfidenceThresholdResult(
                threshold=threshold,
                precision=precision,
                recall=recall,
                f1_score=f1,
                true_positives=tp,
                false_positives=fp,
                false_negatives=fn
            )
            threshold_results.append(result)
            self.confidence_results.append(asdict(result))
        
        # Find optimal threshold
        optimal_result = max(threshold_results, key=lambda r: r.f1_score)
        
        # Confidence statistics
        confidences_correct = [d["confidence"] for d in detections_data if d["is_correct"]]
        confidences_incorrect = [d["confidence"] for d in detections_data if not d["is_correct"]]
        
        results = {
            "optimal_threshold": float(optimal_result.threshold),
            "optimal_f1_score": float(optimal_result.f1_score),
            "optimal_precision": float(optimal_result.precision),
            "optimal_recall": float(optimal_result.recall),
            "confidence_mean_correct": float(np.mean(confidences_correct)) if confidences_correct else 0,
            "confidence_std_correct": float(np.std(confidences_correct)) if confidences_correct else 0,
            "confidence_mean_incorrect": float(np.mean(confidences_incorrect)) if confidences_incorrect else 0,
            "confidence_std_incorrect": float(np.std(confidences_incorrect)) if confidences_incorrect else 0,
            "confidence_separation": float(np.mean(confidences_correct) - np.mean(confidences_incorrect)) if (confidences_correct and confidences_incorrect) else 0,
            "all_thresholds": [asdict(r) for r in threshold_results]
        }
        
        # Print results
        print(f"\n✓ Confidence Threshold Test Complete")
        print(f"  Total Detections: {len(detections_data)}")
        print(f"  Correct: {len(confidences_correct)}, Incorrect: {len(confidences_incorrect)}")
        print(f"\n  OPTIMAL THRESHOLD: {results['optimal_threshold']:.2f}")
        print(f"    Precision: {results['optimal_precision']:.4f}")
        print(f"    Recall:    {results['optimal_recall']:.4f}")
        print(f"    F1-Score:  {results['optimal_f1_score']:.4f}")
        print(f"\n  CONFIDENCE STATISTICS:")
        print(f"    Correct Detections:    μ={results['confidence_mean_correct']:.4f}, σ={results['confidence_std_correct']:.4f}")
        print(f"    Incorrect Detections:  μ={results['confidence_mean_incorrect']:.4f}, σ={results['confidence_std_incorrect']:.4f}")
        print(f"    Confidence Separation: {results['confidence_separation']:.4f}")
        print(f"\n  THRESHOLD BREAKDOWN:")
        for tr in threshold_results:
            print(f"    {tr.threshold:.1f}: Precision={tr.precision:.4f}, Recall={tr.recall:.4f}, "
                  f"F1={tr.f1_score:.4f}, TP={tr.true_positives}, FP={tr.false_positives}")
        
        return results
    
    # ====================================================================
    # METRIC 5: TEMPORAL CONSISTENCY
    # ====================================================================
    
    def test_temporal_consistency(self, pose_sequence: List[Tuple[float, float, float]]) -> Dict:
        """
        Test 5: Temporal Consistency (Frame-to-Frame Stability)
        
        Input: pose_sequence - List of (x, y, z) coordinates from consecutive frames
        Example:
        [
            (0.100, 0.050, 0.300),  # Frame 1
            (0.102, 0.048, 0.298),  # Frame 2
            (0.099, 0.051, 0.301),  # Frame 3
            ...
        ]
        
        Process:
        1. For 200+ consecutive frames on stationary target
        2. Calculate std deviation of X, Y, Z coordinates
        3. Calculate drift (distance from start to end)
        4. Calculate stability index
        """
        print("\n" + "=" * 70)
        print("TEST 5: TEMPORAL CONSISTENCY (Frame-to-Frame Stability)")
        print("=" * 70)
        
        if len(pose_sequence) < 50:
            print("✗ Insufficient pose samples (need at least 50 frames)")
            return {}
        
        # Extract coordinates
        x_coords = np.array([p[0] for p in pose_sequence])
        y_coords = np.array([p[1] for p in pose_sequence])
        z_coords = np.array([p[2] for p in pose_sequence])
        
        # Calculate statistics
        x_std = np.std(x_coords)
        y_std = np.std(y_coords)
        z_std = np.std(z_coords)
        
        x_mean = np.mean(x_coords)
        y_mean = np.mean(y_coords)
        z_mean = np.mean(z_coords)
        
        # Position jitter (deviation between consecutive frames)
        x_jitter = np.mean(np.abs(np.diff(x_coords)))
        y_jitter = np.mean(np.abs(np.diff(y_coords)))
        z_jitter = np.mean(np.abs(np.diff(z_coords)))
        
        # Drift (total displacement from start to end)
        drift = np.sqrt((x_coords[0] - x_coords[-1])**2 + 
                       (y_coords[0] - y_coords[-1])**2 + 
                       (z_coords[0] - z_coords[-1])**2)
        
        # Stability index (higher is better)
        mean_position = np.mean([x_std, y_std, z_std])
        mean_distance = np.sqrt(x_mean**2 + y_mean**2 + z_mean**2)
        stability_index = (1 - (mean_position / mean_distance)) * 100 if mean_distance > 0 else 0
        
        # Max deviation from mean
        x_max_dev = np.max(np.abs(x_coords - x_mean))
        y_max_dev = np.max(np.abs(y_coords - y_mean))
        z_max_dev = np.max(np.abs(z_coords - z_mean))
        
        results = {
            "total_frames": len(pose_sequence),
            "x_std_m": float(x_std),
            "y_std_m": float(y_std),
            "z_std_m": float(z_std),
            "x_jitter_m": float(x_jitter),
            "y_jitter_m": float(y_jitter),
            "z_jitter_m": float(z_jitter),
            "drift_m": float(drift),
            "stability_index_percent": float(stability_index),
            "x_max_deviation_m": float(x_max_dev),
            "y_max_deviation_m": float(y_max_dev),
            "z_max_deviation_m": float(z_max_dev),
            "mean_position_m": float(np.array([x_mean, y_mean, z_mean]).mean())
        }
        
        # Print results
        print(f"\n✓ Temporal Consistency Test Complete")
        print(f"  Total Frames: {len(pose_sequence)}")
        print(f"  Mean Position: ({x_mean:.4f}, {y_mean:.4f}, {z_mean:.4f})m")
        print(f"\n  POSITION JITTER (σ of coordinates):")
        print(f"    X-axis: {results['x_std_m']:.6f}m ({results['x_std_m']*100:.2f}cm)")
        print(f"    Y-axis: {results['y_std_m']:.6f}m ({results['y_std_m']*100:.2f}cm)")
        print(f"    Z-axis: {results['z_std_m']:.6f}m ({results['z_std_m']*100:.2f}cm)")
        print(f"\n  FRAME-TO-FRAME JITTER (mean absolute difference):")
        print(f"    X-axis: {results['x_jitter_m']:.6f}m ({results['x_jitter_m']*100:.2f}cm)")
        print(f"    Y-axis: {results['y_jitter_m']:.6f}m ({results['y_jitter_m']*100:.2f}cm)")
        print(f"    Z-axis: {results['z_jitter_m']:.6f}m ({results['z_jitter_m']*100:.2f}cm)")
        print(f"\n  DRIFT & STABILITY:")
        print(f"    Drift (start to end):  {results['drift_m']:.6f}m ({results['drift_m']*1000:.2f}mm)")
        print(f"    Stability Index:       {results['stability_index_percent']:.2f}%")
        print(f"    Max X Deviation:       {results['x_max_deviation_m']:.6f}m")
        print(f"    Max Y Deviation:       {results['y_max_deviation_m']:.6f}m")
        print(f"    Max Z Deviation:       {results['z_max_deviation_m']:.6f}m")
        
        return results
    
    # ====================================================================
    # REPORT GENERATION
    # ====================================================================
    
    def generate_report(self, all_results: Dict) -> str:
        """Generate comprehensive test report"""
        report_dir = Path(self.config["output_dir"])
        report_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = report_dir / f"test_report_{timestamp}.json"
        
        with open(report_file, 'w') as f:
            json.dump(all_results, f, indent=2)
        
        print(f"\n{'='*70}")
        print("REPORT GENERATED")
        print(f"{'='*70}")
        print(f"Location: {report_file}")
        
        return str(report_file)


# ====================================================================
# HELPER FUNCTIONS FOR DATA COLLECTION
# ====================================================================

def collect_depth_measurements_interactive():
    """Interactive function to collect depth measurements"""
    print("\n" + "="*70)
    print("DEPTH MEASUREMENT COLLECTION TOOL")
    print("="*70)
    print("\nThis tool helps you collect ground truth depth measurements.")
    print("You will need: measuring tape and the camera_node running.")
    
    measurements = {}
    distances = [0.15, 0.20, 0.25, 0.30, 0.40, 0.50]
    
    for distance in distances:
        print(f"\n--- Testing distance: {distance}m ---")
        input(f"Place tomato at {distance}m and press Enter...")
        
        z_values = []
        for i in range(10):
            z = float(input(f"  Measurement {i+1}/10 - Enter z_coordinate from goal_pose: "))
            z_values.append(z)
        
        measurements[distance] = z_values
        print(f"✓ Recorded {len(z_values)} measurements at {distance}m")
    
    return measurements


def collect_xy_ground_truth():
    """Interactive function to collect XY ground truth bounding boxes"""
    print("\n" + "="*70)
    print("XY GROUND TRUTH BOUNDING BOX COLLECTION")
    print("="*70)
    
    bboxes = {}
    test_dir = Path("test_images")
    
    if not test_dir.exists():
        print("✗ test_images directory not found!")
        return bboxes
    
    img_files = list(test_dir.glob("*.jpg"))
    print(f"Found {len(img_files)} test images")
    
    for img_file in img_files[:10]:  # Limit to first 10
        print(f"\nImage: {img_file.name}")
        img = cv2.imread(str(img_file))
        
        if img is None:
            continue
        
        print("Click and drag to draw bounding box (close window when done)")
        
        bbox = cv2.selectROI(img_file.name, img)
        bboxes[img_file.name] = bbox
        cv2.destroyWindow(img_file.name)
    
    return bboxes


def collect_temporal_data_from_ros():
    """Collect temporal consistency data from ROS topic (requires running node)"""
    print("\n" + "="*70)
    print("TEMPORAL DATA COLLECTION FROM ROS")
    print("="*70)
    print("Make sure:")
    print("1. Camera node is running")
    print("2. Tomato is placed at fixed position (0.3m away)")
    print("3. Node is publishing to /tomato/goal_pose")
    
    rclpy.init()
    
    class PoseCollector(Node):
        def __init__(self):
            super().__init__('pose_collector')
            self.poses = []
            self.subscription = self.create_subscription(
                PoseStamped,
                '/tomato/goal_pose',
                self.pose_callback,
                10
            )
            self.start_time = time.time()
        
        def pose_callback(self, msg: PoseStamped):
            if len(self.poses) < 200:  # Collect 200 frames
                x = msg.pose.position.x
                y = msg.pose.position.y
                z = msg.pose.position.z
                self.poses.append((x, y, z))
                
                if len(self.poses) % 50 == 0:
                    print(f"✓ Collected {len(self.poses)} poses...")
    
    collector = PoseCollector()
    
    print("Collecting 200 frames (6-7 seconds at 30Hz)...")
    while len(collector.poses) < 200:
        rclpy.spin_once(collector, timeout_sec=0.1)
    
    rclpy.shutdown()
    print(f"✓ Collected {len(collector.poses)} temporal data points")
    
    return collector.poses


# ====================================================================
# MAIN EXECUTION
# ====================================================================

def main():
    """Main testing function"""
    tester = TomatoDetectionTester()
    
    all_results = {}
    
    # TEST 1: Classification Accuracy
    print("\n" + "█"*70)
    print("█ Running Test 1: Classification Accuracy")
    print("█"*70)
    results_1 = tester.test_classification_accuracy()
    all_results["classification_accuracy"] = results_1
    
    # TEST 2: Depth Estimation
    print("\n" + "█"*70)
    print("█ Running Test 2: Depth Estimation (RMSE)")
    print("█"*70)
    print("\nOption 1: Provide manual measurements (interactive)")
    print("Option 2: Load from file")
    
    # Example: Collect interactively or use sample data
    depth_measurements = {
        0.20: [0.198, 0.202, 0.195, 0.201, 0.199, 0.203, 0.197, 0.200, 0.204, 0.196],
        0.30: [0.298, 0.305, 0.301, 0.299, 0.302, 0.303, 0.300, 0.304, 0.297, 0.301],
        0.40: [0.398, 0.402, 0.399, 0.401, 0.400, 0.403, 0.397, 0.404, 0.398, 0.402]
    }
    results_2 = tester.test_depth_estimation(depth_measurements)
    all_results["depth_estimation"] = results_2
    
    # TEST 3: XY Accuracy
    print("\n" + "█"*70)
    print("█ Running Test 3: XY Coordinate Accuracy")
    print("█"*70)
    
    ground_truth_bboxes = {
        "tomato_001.jpg": (100, 150, 250, 280),
        "tomato_002.jpg": (80, 120, 220, 310),
        "tomato_003.jpg": (120, 100, 280, 300),
    }
    results_3 = tester.test_xy_accuracy(ground_truth_bboxes)
    all_results["xy_accuracy"] = results_3
    
    # TEST 4: Confidence Threshold
    print("\n" + "█"*70)
    print("█ Running Test 4: Confidence Threshold Optimization")
    print("█"*70)
    
    detections_data = [
        {"confidence": 0.95, "is_correct": True},
        {"confidence": 0.92, "is_correct": True},
        {"confidence": 0.88, "is_correct": True},
        {"confidence": 0.85, "is_correct": False},
        {"confidence": 0.42, "is_correct": False},
        {"confidence": 0.38, "is_correct": False},
        {"confidence": 0.35, "is_correct": False},
    ]
    results_4 = tester.test_confidence_thresholds(detections_data)
    all_results["confidence_threshold"] = results_4
    
    # TEST 5: Temporal Consistency
    print("\n" + "█"*70)
    print("█ Running Test 5: Temporal Consistency")
    print("█"*70)
    
    temporal_data = [
        (0.100, 0.050, 0.300), (0.102, 0.048, 0.298), (0.099, 0.051, 0.301),
        (0.101, 0.049, 0.299), (0.100, 0.050, 0.300), (0.103, 0.047, 0.297),
        (0.098, 0.052, 0.302), (0.102, 0.048, 0.298), (0.100, 0.050, 0.300),
    ] * 20  # Repeat to get 180 frames
    results_5 = tester.test_temporal_consistency(temporal_data)
    all_results["temporal_consistency"] = results_5
    
    # Generate Report
    report_path = tester.generate_report(all_results)
    
    print("\n" + "="*70)
    print("ALL TESTS COMPLETED SUCCESSFULLY!")
    print("="*70)
    print(f"Report saved to: {report_path}")
    
    return all_results


if __name__ == "__main__":
    main()