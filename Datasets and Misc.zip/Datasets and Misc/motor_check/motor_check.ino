#include <Servo.h>

Servo servoMap[11];  // Array indexed by pin number; only using relevant pins 3,5,6,9,10
const int validPins[] = {3, 5, 6, 9, 10};
const byte numServos = sizeof(validPins) / sizeof(validPins[0]);

char inputString[32];  // Buffer for serial input
byte inputPos = 0;

int currentAngles[11]; // Store current angle of each servo, indexed by pin number

void setup() {
  Serial.begin(9600);
  Serial.println("Ready to receive commands in format: pin,angle");

  // Attach servos on specified pins and initialize at 90 degrees
  for (byte i = 0; i < numServos; i++) {
    int pin = validPins[i];
    servoMap[pin].attach(pin);
    servoMap[pin].write(90);
    currentAngles[pin] = 90;
  }
}

void loop() {
  while (Serial.available() > 0) {
    char inChar = Serial.read();

    if (inChar == '\n') {
      inputString[inputPos] = '\0';
      processCommand(inputString);
      inputPos = 0;
    } else if (inputPos < sizeof(inputString) - 1) {
      inputString[inputPos++] = inChar;
    }
  }
}

void processCommand(char* command) {
  // Parse command in format "pin,angle"
  char* token = strtok(command, ",");
  if (token == NULL) {
    Serial.println("Error: No pin provided");
    return;
  }
  int pin = atoi(token);

  token = strtok(NULL, ",");
  if (token == NULL) {
    Serial.println("Error: No angle provided");
    return;
  }
  int angle = atoi(token);

  if (!angleValid(angle)) {
    Serial.println("Error: Angle must be between 0 and 180");
    return;
  }
  if (!pinValid(pin)) {
    Serial.print("Error: Invalid pin. Use one of: ");
    for (byte i = 0; i < numServos; i++) {
      Serial.print(validPins[i]);
      if (i < numServos - 1) Serial.print(", ");
    }
    Serial.println();
    return;
  }

  Serial.print("Moving servo on pin ");
  Serial.print(pin);
  Serial.print(" to angle ");
  Serial.println(angle);

  moveServoSmoothly(pin, angle, 2000);  // Move over 2 seconds

  Serial.println("Move complete");
}

void moveServoSmoothly(int pin, int targetAngle, int duration) {
  int startAngle = currentAngles[pin];
  int delta = targetAngle - startAngle;
  int steps = 50; // Number of incremental moves
  int delayTime = duration / steps;

  for (int i = 1; i <= steps; i++) {
    int newAngle = startAngle + (delta * i) / steps;
    servoMap[pin].write(newAngle);
    currentAngles[pin] = newAngle;
    delay(delayTime);
  }
}

bool pinValid(int pin) {
  for (byte i = 0; i < numServos; i++) {
    if (validPins[i] == pin) return true;
  }
  return false;
}

bool angleValid(int angle) {
  return (angle >= 0 && angle <= 180);
}
  
