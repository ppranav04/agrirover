/*
 * Arduino Servo Controller for TRR Robot Arm - FIXED v2
 * 
 * Features:
 * - Controls 4 servo motors on pins 3, 6, 9, 10 (PWM pins)
 * - Receives angle commands via serial (9600 baud)
 * - Smooth interpolation for servo movement
 * - Enhanced debugging and error handling
 * - Command format: "angle1,angle2,angle3,angle4\n"
 * - Example: "90,45,120,60\n"
 */

#include <Servo.h>
#include <Arduino.h>

// ============================================================
// CONFIGURATION
// ============================================================

#define BAUD_RATE 9600
#define MAX_BUFFER_SIZE 50
#define NUM_SERVOS 4
#define SERVO_MIN_ANGLE 0
#define SERVO_MAX_ANGLE 180
#define SERVO_MIN_PWM 1000      // 1ms pulse
#define SERVO_MAX_PWM 2000      // 2ms pulse
#define HOME_POSITION_1 90
#define HOME_POSITION_2 0
#define HOME_POSITION_3 180
#define HOME_POSITION_4 0
#define INTERPOLATION_DELAY_MS 10  // Delay between interpolation steps

// ============================================================
// SERVO PINS (PWM capable)
// ============================================================

const uint8_t servo_pins[NUM_SERVOS] = {
  3,   // Servo 1: Base rotation (Pin 3, Timer2)
  6,   // Servo 2: Shoulder (Pin 6, Timer4)
  9,   // Servo 3: Elbow (Pin 9, Timer1)
  10   // Servo 4: Gripper (Pin 10, Timer1)
};

// ============================================================
// GLOBAL VARIABLES
// ============================================================

Servo servos[NUM_SERVOS];
uint16_t current_angles[NUM_SERVOS] = {HOME_POSITION_1, HOME_POSITION_2, HOME_POSITION_3, HOME_POSITION_4};
uint16_t target_angles[NUM_SERVOS] = {HOME_POSITION_1, HOME_POSITION_2, HOME_POSITION_3, HOME_POSITION_4};

char serial_buffer[MAX_BUFFER_SIZE];
uint8_t buffer_index = 0;
bool data_ready = false;

unsigned long last_update = 0;
unsigned long last_serial_check = 0;
unsigned long commands_received = 0;

// ============================================================
// SETUP
// ============================================================

void setup() {
  // Initialize serial communication
  Serial.begin(BAUD_RATE);
  delay(1000);  // Wait for serial to stabilize
  
  // Initialize all servos
  for (uint8_t i = 0; i < NUM_SERVOS; i++) {
    servos[i].attach(servo_pins[i], SERVO_MIN_PWM, SERVO_MAX_PWM);
    servos[i].write(current_angles[i]);
  }
  
  // Clear serial buffers
  Serial.flush();
  delay(100);
  
  // Print startup message
  Serial.println("\n\n========================================");
  Serial.println("Arduino Servo Controller v2 - STARTED");
  Serial.println("========================================");
  Serial.print("Baud Rate: ");
  Serial.println(BAUD_RATE);
  Serial.print("Servos: ");
  Serial.println(NUM_SERVOS);
  Serial.print("Servo Pins: ");
  for (uint8_t i = 0; i < NUM_SERVOS; i++) {
    Serial.print(servo_pins[i]);
    if (i < NUM_SERVOS - 1) Serial.print(", ");
  }
  Serial.println();
  Serial.println("Command format: angle1,angle2,angle3,angle4");
  Serial.println("Example: 90,45,120,60");
  Serial.println("Commands received will be echoed here");
  Serial.println("========================================");
  Serial.println();
  
  print_current_angles();
}

// ============================================================
// MAIN LOOP
// ============================================================

void loop() {
  unsigned long now = millis();
  
  // Check for incoming serial data
  if (now - last_serial_check >= 5) {
    last_serial_check = now;
    read_serial_command();
  }
  
  // Process command if complete
  if (data_ready) {
    parse_command();
    data_ready = false;
  }
  
  // Smooth interpolation towards target angles
  if (now - last_update >= INTERPOLATION_DELAY_MS) {
    last_update = now;
    interpolate_servos();
  }
}

// ============================================================
// SERIAL COMMUNICATION
// ============================================================

void read_serial_command() {
  /*
   * Read incoming serial data and build command string
   * Format: "angle1,angle2,angle3,angle4\n"
   */
  
  while (Serial.available() > 0) {
    char c = Serial.read();
    
    // Echo received character for debugging
    Serial.write(c);
    
    if (c == '\n' || c == '\r') {
      // End of command
      if (buffer_index > 0) {
        serial_buffer[buffer_index] = '\0';
        data_ready = true;
        Serial.println();  // New line after echoed command
        buffer_index = 0;
      }
    } else if (buffer_index < MAX_BUFFER_SIZE - 1) {
      serial_buffer[buffer_index++] = c;
    } else {
      // Buffer overflow - reset
      buffer_index = 0;
      Serial.println("\nERROR: Buffer overflow! Input too long.");
    }
  }
}

void parse_command() {
  /*
   * Parse comma-separated angle values
   * Expected format: "angle1,angle2,angle3,angle4"
   * Example: "90,45,120,60"
   */
  
  uint16_t parsed_angles[NUM_SERVOS];
  uint8_t parsed_count = 0;
  char *ptr = serial_buffer;
  char *end;
  
  Serial.print(">> Parsing: ");
  Serial.println(serial_buffer);
  
  // Parse each angle
  for (uint8_t i = 0; i < NUM_SERVOS; i++) {
    long value = strtol(ptr, &end, 10);
    
    // Check if parsing succeeded
    if (end == ptr) {
      Serial.print("✗ ERROR: Failed to parse angle ");
      Serial.println(i + 1);
      return;
    }
    
    // Validate angle range
    if (value < SERVO_MIN_ANGLE || value > SERVO_MAX_ANGLE) {
      Serial.print("✗ ERROR: Angle ");
      Serial.print(i + 1);
      Serial.print(" out of range: ");
      Serial.print(value);
      Serial.print("° (valid: 0-180°)");
      Serial.println();
      return;
    }
    
    parsed_angles[i] = (uint16_t)value;
    parsed_count++;
    
    Serial.print("   Servo ");
    Serial.print(i + 1);
    Serial.print(": ");
    Serial.print(parsed_angles[i]);
    Serial.println("°");
    
    // Move to next comma
    if (i < NUM_SERVOS - 1) {
      if (*end != ',') {
        Serial.print("✗ ERROR: Expected comma after angle ");
        Serial.println(i + 1);
        return;
      }
      ptr = end + 1;
    }
  }
  
  // All angles parsed successfully
  if (parsed_count == NUM_SERVOS) {
    for (uint8_t i = 0; i < NUM_SERVOS; i++) {
      target_angles[i] = parsed_angles[i];
    }
    
    commands_received++;
    Serial.print("✓ CMD #");
    Serial.print(commands_received);
    Serial.print(" accepted. Target: [");
    for (uint8_t i = 0; i < NUM_SERVOS; i++) {
      Serial.print(target_angles[i]);
      if (i < NUM_SERVOS - 1) Serial.print(", ");
    }
    Serial.println("]");
  }
}

// ============================================================
// SERVO CONTROL
// ============================================================

void interpolate_servos() {
  /*
   * Smooth interpolation towards target angles
   * Uses linear interpolation with small step size
   */
  
  bool all_reached = true;
  int16_t step_size = 2;  // Degrees per interpolation step
  
  for (uint8_t i = 0; i < NUM_SERVOS; i++) {
    if (current_angles[i] != target_angles[i]) {
      all_reached = false;
      
      // Calculate direction and apply step
      if (current_angles[i] < target_angles[i]) {
        current_angles[i] = min(current_angles[i] + step_size, target_angles[i]);
      } else {
        current_angles[i] = max((int16_t)current_angles[i] - step_size, (int16_t)target_angles[i]);
      }
      
      // Write to servo
      servos[i].write(current_angles[i]);
    }
  }
  
  // Print status when all servos reach target
  if (all_reached && !data_ready) {
    static unsigned long last_print = 0;
    static uint16_t last_angles[NUM_SERVOS] = {255, 255, 255, 255};
    
    // Print when position changes or every 2 seconds when idle
    bool position_changed = false;
    for (uint8_t i = 0; i < NUM_SERVOS; i++) {
      if (current_angles[i] != last_angles[i]) {
        position_changed = true;
        last_angles[i] = current_angles[i];
      }
    }
    
    if (position_changed) {
      Serial.print("◆ Current: [");
      for (uint8_t i = 0; i < NUM_SERVOS; i++) {
        Serial.print(current_angles[i]);
        if (i < NUM_SERVOS - 1) Serial.print(", ");
      }
      Serial.println("]°");
      last_print = millis();
    }
  }
}

// ============================================================
// UTILITY FUNCTIONS
// ============================================================

void print_current_angles() {
  Serial.print("Initial: [");
  for (uint8_t i = 0; i < NUM_SERVOS; i++) {
    Serial.print(current_angles[i]);
    if (i < NUM_SERVOS - 1) Serial.print(", ");
  }
  Serial.println("]°");
  Serial.println("Ready to receive commands...\n");
}

void print_servo_info() {
  Serial.println("\n========== SERVO INFO ==========");
  for (uint8_t i = 0; i < NUM_SERVOS; i++) {
    Serial.print("Servo ");
    Serial.print(i + 1);
    Serial.print(" | Pin: ");
    Serial.print(servo_pins[i]);
    Serial.print(" | Current: ");
    Serial.print(current_angles[i]);
    Serial.print("° | Target: ");
    Serial.print(target_angles[i]);
    Serial.println("°");
  }
  Serial.print("Total commands received: ");
  Serial.println(commands_received);
  Serial.println("================================\n");
}

void test_servos() {
  /*
   * Test sequence: Move each servo through full range
   * Sends test commands to serial output
   */
  
  Serial.println("\n========== SERVO TEST ==========");
  
  for (uint8_t servo = 0; servo < NUM_SERVOS; servo++) {
    Serial.print("Testing Servo ");
    Serial.println(servo + 1);
    
    // Move to min
    servos[servo].write(SERVO_MIN_ANGLE);
    Serial.println("  → Min (0°)");
    delay(500);
    
    // Move to max
    servos[servo].write(SERVO_MAX_ANGLE);
    Serial.println("  → Max (180°)");
    delay(500);
    
    // Return to home
    servos[servo].write(current_angles[servo]);
  }
  
  Serial.println("Test complete\n");
}
